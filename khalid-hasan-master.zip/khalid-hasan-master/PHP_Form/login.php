<!doctype html>
<html>
<head>
	<title>Login Form</title>
</head>
<body>
<h1><u>Login From</u></h1>
<form action="login_handler.php" method="post">
	<table>
		<tr>
			<td>Username/login</td>
			<td><input type="text"name="username"></td>
		
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password"name="password"></td>
		
		</tr>
		<tr>
			<td></td>
			<td><button type="button">Cancel</button> <input type="submit" value="Submit"></td>
		</tr>
		<tr>
			<td></td>
			<td><h2>OR,</h2></td>
		</tr>
	</table>
</form>

</body>
</html>